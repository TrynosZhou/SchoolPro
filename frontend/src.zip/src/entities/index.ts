import { User } from './User';
import { SchoolRole } from './SchoolRole';
import { SchoolYear } from './SchoolYear';
import { Term } from './Term';
import { Form } from './Form';
import { SchoolClass } from './SchoolClass';
import { Subject } from './Subject';
import { Department } from './Department';
import { ClassSubject } from './ClassSubject';
import { Section } from './Section';
import { TeacherAssignment } from './TeacherAssignment';
import { TimetableSlot } from './TimetableSlot';
import { Parent } from './Parent';
import { Student } from './Student';
import { Guardian } from './Guardian';
import { Staff } from './Staff';
import { StaffAttendance } from './StaffAttendance';
import { StudentAttendance } from './StudentAttendance';
import { ExamType } from './ExamType';
import { ExamMark } from './ExamMark';
import { ReportCard } from './ReportCard';
import { HonourRoll } from './HonourRoll';
import { Invoice } from './Invoice';
import { InvoiceLine } from './InvoiceLine';
import { Payment } from './Payment';
import { Receipt } from './Receipt';
import { LedgerEntry } from './LedgerEntry';
import { CashbookEntry } from './CashbookEntry';
import { Timetable } from './Timetable';
import { TeacherAllocation } from './TeacherAllocation';
import { LearningSchedule } from './LearningSchedule';
import { WeeklyAssessment } from './WeeklyAssessment';
import { Message } from './Message';
import { MessageAttachment } from './MessageAttachment';
import { Notification } from './Notification';
import { TuckshopItem } from './TuckshopItem';
import { TuckshopSale } from './TuckshopSale';
import { UniformSale } from './UniformSale';
import { SchoolSettings } from './SchoolSettings';
import { SchoolFee } from './SchoolFee';
import { ClassPromotionRule } from './ClassPromotionRule';
import { ResultsPublication } from './ResultsPublication';
import { ReportCardView } from './ReportCardView';
import { StudentTermBalance } from './StudentTermBalance';
import { StaffPayrollProfile } from './StaffPayrollProfile';
import { PayrollRun } from './PayrollRun';
import { Payslip } from './Payslip';
import { StaffLeaveBalance } from './StaffLeaveBalance';
import { LeaveRequest } from './LeaveRequest';
import { TuitionExemption } from './TuitionExemption';
import { InvoiceAdjustment } from './InvoiceAdjustment';
import { ChartOfAccount } from './ChartOfAccount';
import { GeneralLedgerEntry } from './GeneralLedgerEntry';
import { Application } from './Application';
import { ApplicationDocument } from './ApplicationDocument';
import { BulkMessage } from './BulkMessage';
import { BulkMessageRecipient } from './BulkMessageRecipient';
import { StudentEnrollment } from './StudentEnrollment';
import { ReportTemplate } from './ReportTemplate';
import { AuditLog } from './AuditLog';
import { RecordBookColumn } from './RecordBookColumn';
import { RecordBookMark } from './RecordBookMark';
import { HomeworkAssignment } from './HomeworkAssignment';
import { NotificationLog } from './NotificationLog';
import { LmsAssignment } from './LmsAssignment';
import { LmsSubmission } from './LmsSubmission';
import { LessonContent } from './LessonContent';
import { VirtualClass } from './VirtualClass';
import { ClassRecording } from './ClassRecording';
import { LibraryResource } from './LibraryResource';
import { LibraryBookmark } from './LibraryBookmark';

export const entities = [
  User,
  SchoolRole,
  SchoolSettings,
  SchoolFee,
  ClassPromotionRule,
  ResultsPublication,
  ReportCardView,
  StudentTermBalance,
  SchoolYear,
  Term,
  Form,
  SchoolClass,
  Subject,
  Department,
  ClassSubject,
  Section,
  TeacherAssignment,
  TimetableSlot,
  Parent,
  Student,
  Guardian,
  Staff,
  StaffAttendance,
  StudentAttendance,
  ExamType,
  ExamMark,
  ReportCard,
  HonourRoll,
  Invoice,
  InvoiceLine,
  Payment,
  Receipt,
  LedgerEntry,
  CashbookEntry,
  Timetable,
  TeacherAllocation,
  LearningSchedule,
  WeeklyAssessment,
  Message,
  MessageAttachment,
  Notification,
  TuckshopItem,
  TuckshopSale,
  UniformSale,
  StaffPayrollProfile,
  PayrollRun,
  Payslip,
  StaffLeaveBalance,
  LeaveRequest,
  TuitionExemption,
  InvoiceAdjustment,
  ChartOfAccount,
  GeneralLedgerEntry,
  Application,
  ApplicationDocument,
  BulkMessage,
  BulkMessageRecipient,
  StudentEnrollment,
  ReportTemplate,
  AuditLog,
  RecordBookColumn,
  RecordBookMark,
  HomeworkAssignment,
  NotificationLog,
  LmsAssignment,
  LmsSubmission,
  LessonContent,
  VirtualClass,
  ClassRecording,
  LibraryResource,
  LibraryBookmark,
];

export * from './enums';
export {
  User,
  SchoolRole,
  SchoolYear,
  Term,
  Form,
  SchoolClass,
  Subject,
  Department,
  ClassSubject,
  Section,
  TeacherAssignment,
  TimetableSlot,
  Parent,
  Student,
  Guardian,
  Staff,
  StaffAttendance,
  StudentAttendance,
  ExamType,
  ExamMark,
  ReportCard,
  HonourRoll,
  Invoice,
  InvoiceLine,
  Payment,
  Receipt,
  LedgerEntry,
  CashbookEntry,
  Timetable,
  TeacherAllocation,
  LearningSchedule,
  WeeklyAssessment,
  Message,
  MessageAttachment,
  Notification,
  TuckshopItem,
  TuckshopSale,
  UniformSale,
  SchoolSettings,
  SchoolFee,
  ClassPromotionRule,
  ResultsPublication,
  ReportCardView,
  StudentTermBalance,
  StaffPayrollProfile,
  PayrollRun,
  Payslip,
  StaffLeaveBalance,
  LeaveRequest,
  TuitionExemption,
  InvoiceAdjustment,
  ChartOfAccount,
  GeneralLedgerEntry,
  Application,
  ApplicationDocument,
  BulkMessage,
  BulkMessageRecipient,
  StudentEnrollment,
  ReportTemplate,
  AuditLog,
  RecordBookColumn,
  RecordBookMark,
  HomeworkAssignment,
  NotificationLog,
  LmsAssignment,
  LmsSubmission,
  LessonContent,
  VirtualClass,
  ClassRecording,
  LibraryResource,
  LibraryBookmark,
};

