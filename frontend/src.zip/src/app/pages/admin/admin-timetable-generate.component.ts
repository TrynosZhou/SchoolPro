import { blobErrorMessage } from '../../core/utils/blob-error.util';
import { Component, computed, HostListener, inject, OnDestroy, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgStyle, NgTemplateOutlet } from '@angular/common';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { RouterLink } from '@angular/router';
import { PortalLayoutComponent } from '../../shared/portal-layout/portal-layout.component';
import { TeacherAssignmentsModalComponent } from '../../shared/teacher-assignments-modal/teacher-assignments-modal.component';
import { ADMIN_NAV_SECTIONS } from '../../core/config/admin-nav';
import { ApiService } from '../../core/services/api.service';
import { TimetablePeriod, TimetablePeriodsService } from '../../core/services/timetable-periods.service';
import { classHeaderLabel } from '../../core/utils/class-display';
import {
  breakPeriodLabel,
  breakColumnVerticalLabel,
  breakPeriodHeaderTitle,
  dayGridLabel,
  formatPeriodRange,
  isBreakPeriod,
  lessonPeriodNumber,
  lessonPeriodCount,
  shortClassCode,
  compactClassGridLabel,
  teacherInitials,
  timetableSubjectShort,
} from '../../core/utils/timetable-grid-display';
import {
  buildTimetableTermVersionLabel,
  normalizeTimetableVersion,
  timetableTermPrefix,
} from '../../core/utils/timetable-term-label';
import { buildTeacherColorMap, teacherColorFor, TeacherColorStyle } from '../../core/utils/teacher-colors';

type ResultTab = 'teachers' | 'classes' | 'summary';
type EditorMode = 'teachers' | 'classes';
type EditorPdfMode = 'teachers' | 'classes';

interface TimetableSlotView {
  id: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  classId: string;
  className: string;
  subjectId: string;
  subjectName: string;
  subjectCode?: string | null;
  subjectShort?: string | null;
  teacherId: string;
  teacherName: string;
  employeeNumber?: string;
  room?: string | null;
  isLocked?: boolean;
}

interface TeacherTimetableView {
  teacherId: string;
  teacherName: string;
  employeeNumber: string;
  slotCount: number;
  classCount: number;
  subjectCount: number;
  slots: TimetableSlotView[];
}

interface ClassTimetableView {
  classId: string;
  className: string;
  slotCount: number;
  subjectCount: number;
  slots: TimetableSlotView[];
}

interface TeacherSummaryRow {
  teacherId: string;
  teacherName: string;
  employeeNumber: string;
  totalPeriods: number;
  classCount: number;
  subjectCount: number;
  assignments: {
    classId: string;
    className: string;
    subjectId: string;
    subjectName: string;
    weeklyPeriods: number;
    lessonLength: string;
    scheduledPeriods: number;
    requiredPeriods: number;
  }[];
}

interface GenerateTimetableResult {
  timetableVersion?: string;
  success: boolean;
  summary: {
    totalSlots: number;
    classesScheduled: number;
    teachersScheduled: number;
    assignmentsPlaced: number;
    assignmentsPartial: number;
    assignmentsFailed: number;
    capacityPerWeek: number;
    requiredSlots: number;
  };
  failures: {
    className: string;
    subjectName: string;
    teacherName: string;
    requiredPeriods: number;
    scheduledPeriods: number;
    reason: string;
  }[];
  teachers: TeacherTimetableView[];
  classes: ClassTimetableView[];
  teacherSummary: TeacherSummaryRow[];
}

interface LessonDraft {
  id: string;
  classId: string;
  className: string;
  subjectName: string;
  subjectShort: string;
  /** Editable fields. */
  dayOfWeek: number;
  periodKey: string;
  room: string;
  isLocked: boolean;
  remove: boolean;
  /** Values when the modal opened, used to detect changes. */
  original: { dayOfWeek: number; periodKey: string; room: string; isLocked: boolean };
}

interface LessonPeriodOption {
  key: string;
  label: string;
  startTime: string;
  endTime: string;
}

const DAYS = [
  { value: 1, label: 'Monday', short: 'Mon' },
  { value: 2, label: 'Tuesday', short: 'Tue' },
  { value: 3, label: 'Wednesday', short: 'Wed' },
  { value: 4, label: 'Thursday', short: 'Thu' },
  { value: 5, label: 'Friday', short: 'Fri' },
];

@Component({
  selector: 'app-admin-timetable-generate',
  standalone: true,
  imports: [PortalLayoutComponent, FormsModule, RouterLink, NgStyle, NgTemplateOutlet, TeacherAssignmentsModalComponent],
  templateUrl: './admin-timetable-generate.component.html',
  styleUrl: './admin-timetable-generate.component.scss',
})
export class AdminTimetableGenerateComponent implements OnInit, OnDestroy {
  private api = inject(ApiService);
  private periodsSvc = inject(TimetablePeriodsService);
  private sanitizer = inject(DomSanitizer);
  private slotMoveHintTimer: ReturnType<typeof setTimeout> | null = null;
  private pdfObjectUrl: string | null = null;

  readonly adminNav = ADMIN_NAV_SECTIONS;
  readonly days = DAYS;

  readonly dayGridLabel = dayGridLabel;
  readonly formatPeriodRange = formatPeriodRange;
  readonly shortClassCode = shortClassCode;
  readonly compactClassGridLabel = compactClassGridLabel;
  readonly timetableSubjectShort = timetableSubjectShort;
  readonly teacherInitials = teacherInitials;
  readonly isBreakPeriod = isBreakPeriod;
  readonly breakPeriodLabel = breakPeriodLabel;
  readonly breakPeriodHeaderTitle = breakPeriodHeaderTitle;
  readonly breakColumnVerticalLabel = breakColumnVerticalLabel;
  readonly lessonPeriodNumber = lessonPeriodNumber;
  readonly lessonPeriodCount = lessonPeriodCount;

  periods = signal<TimetablePeriod[]>([]);
  lessonPeriods = computed(() => this.periods().filter((p) => p.slotType === 'lesson'));
  result = signal<GenerateTimetableResult | null>(null);
  loading = signal(true);
  generating = signal(false);
  summaryPdfLoading = signal(false);
  teacherPdfLoading = signal(false);
  classPdfLoading = signal(false);
  editorPdfLoading = signal(false);
  replaceExisting = true;
  toast = signal<{ type: 'success' | 'error'; msg: string } | null>(null);
  resultTab = signal<ResultTab>('teachers');
  selectedTeacherId = '';
  selectedClassId = '';
  draggingSlotId = signal<string | null>(null);
  dragOverKey = signal<string | null>(null);
  slotMoving = signal(false);
  slotContextMenu = signal<{ x: number; y: number; slot: TimetableSlotView } | null>(null);
  teacherContextMenu = signal<{ x: number; y: number; teacherId: string; teacherName: string } | null>(
    null,
  );
  /** "Current assignments" modal: opened by clicking a teacher's initials. */
  assignmentsModal = signal<{ teacherId: string; teacherName: string; employeeNumber: string } | null>(null);
  private assignmentsChanged = false;
  /** Timetable-slot editor (move lessons / rooms / locks): opened from the teacher's right-click menu. */
  lessonsModal = signal<{ teacherId: string; teacherName: string; employeeNumber: string } | null>(null);
  lessonDrafts = signal<LessonDraft[]>([]);
  lessonsSaving = signal(false);
  lessonsError = signal<string | null>(null);
  lessonsAllowDoubleBooking = signal(false);
  slotMoveHint = signal<{
    x: number;
    y: number;
    msg: string;
    above?: boolean;
    action?: { label: string; run: () => void };
  } | null>(null);
  slotLockUpdating = signal(false);
  editorWindow = signal<EditorMode | null>(null);
  editorPdfMode = signal<EditorPdfMode>('teachers');
  pdfPreviewOpen = signal(false);
  pdfPreviewUrl = signal<SafeResourceUrl | null>(null);
  pdfPreviewTitle = signal('');
  pdfDownloadName = signal('timetable.pdf');
  termName = signal<string | null>(null);
  yearName = signal<string | null>(null);
  timetableVersion = signal('1');
  versionSaving = signal(false);
  /** True once the admin has typed a different version; it is then used for the next generation instead of auto-incrementing. */
  private versionEdited = false;
  private serverVersion = '1';

  termPrefix = computed(() => timetableTermPrefix(this.termName(), this.yearName()));
  termVersionLabel = computed(() =>
    buildTimetableTermVersionLabel(this.termName(), this.yearName(), this.timetableVersion()),
  );

  summary = computed(() => this.result()?.summary ?? null);
  failures = computed(() => this.result()?.failures ?? []);
  teachers = computed(() => this.result()?.teachers ?? []);
  classes = computed(() => this.result()?.classes ?? []);
  teacherSummary = computed(() => this.result()?.teacherSummary ?? []);

  selectedTeacher = computed(() =>
    this.teachers().find((t) => t.teacherId === this.selectedTeacherId) ?? null,
  );

  selectedClass = computed(() =>
    this.classes().find((c) => c.classId === this.selectedClassId) ?? null,
  );

  hasResult = computed(() => (this.result()?.summary.totalSlots ?? 0) > 0);

  summaryGridTeachers = computed(() => {
    return this.teachers().map((t) => ({
      teacherId: t.teacherId,
      label: this.teacherInitials(t.teacherName),
      name: t.teacherName,
      employeeNumber: t.employeeNumber,
      slots: t.slots,
    }));
  });

  teacherColorMap = computed(() =>
    buildTeacherColorMap(this.teachers().map((t) => t.teacherId)),
  );

  teacherLegendItems = computed(() =>
    this.teachers().map((t) => ({
      teacherId: t.teacherId,
      label: t.teacherName,
      style: teacherColorFor(t.teacherId, this.teacherColorMap()),
    })),
  );

  editorTitle = computed(() => {
    const mode = this.editorWindow();
    if (mode === 'teachers') return 'Teacher Timetable';
    if (mode === 'classes') return 'Class Timetable';
    return '';
  });

  /** Lesson periods (breaks excluded) offered in the modal's period dropdown. */
  lessonPeriodOptions = computed<LessonPeriodOption[]>(() => {
    const all = this.periods();
    const out: LessonPeriodOption[] = [];
    all.forEach((p, i) => {
      if (isBreakPeriod(p)) return;
      out.push({
        key: this.periodKey(p.startTime, p.endTime),
        label: `Period ${lessonPeriodNumber(all, i)} · ${formatPeriodRange(p)}`,
        startTime: p.startTime,
        endTime: p.endTime,
      });
    });
    return out;
  });

  /** Dropdown options for one lesson; keeps a legacy/custom time selectable so it is never lost. */
  periodOptionsFor(draft: LessonDraft): LessonPeriodOption[] {
    const base = this.lessonPeriodOptions();
    if (base.some((o) => o.key === draft.periodKey)) return base;
    const [startTime, endTime] = draft.periodKey.split('|');
    return [
      ...base,
      { key: draft.periodKey, label: `${formatPeriodRange({ startTime, endTime })} (custom)`, startTime, endTime },
    ];
  }

  private periodKey(startTime: string, endTime: string): string {
    return `${startTime}|${endTime}`;
  }

  private timeMinutes(time: string): number {
    const [h, m] = String(time || '0:00').split(':').map(Number);
    return (h || 0) * 60 + (m || 0);
  }

  private timesOverlap(aKey: string, bKey: string): boolean {
    const [a0, a1] = aKey.split('|');
    const [b0, b1] = bKey.split('|');
    return this.timeMinutes(a0) < this.timeMinutes(b1) && this.timeMinutes(b0) < this.timeMinutes(a1);
  }

  /** Lessons that were changed (moved, re-roomed, lock toggled or removed). */
  changedLessonDrafts = computed(() =>
    this.lessonDrafts().filter(
      (d) =>
        d.remove ||
        d.dayOfWeek !== d.original.dayOfWeek ||
        d.periodKey !== d.original.periodKey ||
        d.room.trim() !== d.original.room.trim() ||
        d.isLocked !== d.original.isLocked,
    ),
  );

  /**
   * Live checks while editing.
   *  - "class": the class already has another lesson in that period (cannot be saved).
   *  - "teacher": the teacher would teach two classes at once (needs the double-booking tick-box).
   */
  lessonIssues = computed(() => {
    const issues = new Map<string, { kind: 'class' | 'teacher'; msg: string }>();
    const drafts = this.lessonDrafts().filter((d) => !d.remove);
    const ownIds = new Set(this.lessonDrafts().map((d) => d.id));

    for (const d of drafts) {
      const classSlots = this.classes().find((c) => c.classId === d.classId)?.slots ?? [];
      const classClash = classSlots.find(
        (s) =>
          !ownIds.has(s.id) &&
          s.dayOfWeek === d.dayOfWeek &&
          this.periodKey(s.startTime, s.endTime) === d.periodKey,
      );
      if (classClash) {
        issues.set(d.id, {
          kind: 'class',
          msg: `${classClash.subjectName} (${classClash.teacherName}) is already scheduled for ${this.classDisplayName(d.className)} in this period.`,
        });
        continue;
      }
      const twin = drafts.find(
        (o) => o.id !== d.id && o.dayOfWeek === d.dayOfWeek && this.timesOverlap(o.periodKey, d.periodKey),
      );
      if (twin) {
        issues.set(d.id, {
          kind: 'teacher',
          msg: `Overlaps with ${this.classDisplayName(twin.className)} (${twin.subjectName}).`,
        });
      }
    }
    return issues;
  });

  hasBlockingLessonIssue = computed(() => [...this.lessonIssues().values()].some((i) => i.kind === 'class'));
  hasTeacherOverlap = computed(() => [...this.lessonIssues().values()].some((i) => i.kind === 'teacher'));

  canSaveLessons = computed(
    () =>
      !this.lessonsSaving() &&
      this.changedLessonDrafts().length > 0 &&
      !this.hasBlockingLessonIssue() &&
      (!this.hasTeacherOverlap() || this.lessonsAllowDoubleBooking()),
  );

  /** Click a teacher's initials to view / edit that teacher's class assignments (lessons). */
  openTeacherAssignments(teacherId: string, teacherName: string) {
    if (!teacherId) return;
    const teacher = this.teachers().find((t) => t.teacherId === teacherId);
    this.closeTeacherContextMenu();
    this.closeSlotContextMenu();
    this.closeSlotMoveHint();
    this.assignmentsChanged = false;
    this.assignmentsModal.set({
      teacherId,
      teacherName: teacherName || teacher?.teacherName || '',
      employeeNumber: teacher?.employeeNumber || '',
    });
    document.body.style.overflow = 'hidden';
  }

  onTeacherAssignmentsChanged() {
    this.assignmentsChanged = true;
  }

  closeTeacherAssignments() {
    this.assignmentsModal.set(null);
    if (!this.editorWindow()) document.body.style.overflow = '';
    if (this.assignmentsChanged) {
      this.assignmentsChanged = false;
      // Assignment changes add/remove timetable slots, so refresh the grids.
      this.loadSnapshot(true);
    }
  }

  /** Edit timetable slots (day / period / room / lock) for a teacher. */
  openTeacherLessons(teacherId: string, teacherName: string) {
    const teacher = this.teachers().find((t) => t.teacherId === teacherId);
    if (!teacher) return;
    this.closeTeacherContextMenu();
    this.closeSlotContextMenu();
    this.closeSlotMoveHint();

    const drafts: LessonDraft[] = [...teacher.slots]
      .sort((a, b) => a.dayOfWeek - b.dayOfWeek || a.startTime.localeCompare(b.startTime))
      .map((slot) => {
        const periodKey = this.periodKey(slot.startTime, slot.endTime);
        const room = slot.room ?? '';
        const locked = !!slot.isLocked;
        return {
          id: slot.id,
          classId: slot.classId,
          className: slot.className,
          subjectName: slot.subjectName,
          subjectShort: timetableSubjectShort(slot.subjectCode, slot.subjectName, slot.subjectShort),
          dayOfWeek: slot.dayOfWeek,
          periodKey,
          room,
          isLocked: locked,
          remove: false,
          original: { dayOfWeek: slot.dayOfWeek, periodKey, room, isLocked: locked },
        };
      });

    this.lessonDrafts.set(drafts);
    this.lessonsError.set(null);
    this.lessonsAllowDoubleBooking.set(false);
    this.lessonsModal.set({
      teacherId,
      teacherName: teacherName || teacher.teacherName,
      employeeNumber: teacher.employeeNumber || '',
    });
    document.body.style.overflow = 'hidden';
  }

  updateLessonDraft(id: string, patch: Partial<Pick<LessonDraft, 'dayOfWeek' | 'periodKey' | 'room' | 'isLocked' | 'remove'>>) {
    this.lessonsError.set(null);
    this.lessonDrafts.update((list) => list.map((d) => (d.id === id ? { ...d, ...patch } : d)));
  }

  resetLessonDraft(id: string) {
    this.lessonsError.set(null);
    this.lessonDrafts.update((list) =>
      list.map((d) => (d.id === id ? { ...d, ...d.original, remove: false } : d)),
    );
  }

  closeTeacherLessons(force = false) {
    if (this.lessonsSaving()) return;
    if (!force && this.changedLessonDrafts().length) {
      const ok = window.confirm('You have unsaved lesson changes. Discard them?');
      if (!ok) return;
    }
    this.lessonsModal.set(null);
    this.lessonDrafts.set([]);
    this.lessonsError.set(null);
    if (!this.editorWindow()) document.body.style.overflow = '';
  }

  saveTeacherLessons() {
    const modal = this.lessonsModal();
    if (!modal || !this.canSaveLessons()) return;

    const options = new Map(this.lessonPeriodOptions().map((o) => [o.key, o]));
    const lessons = this.changedLessonDrafts().map((d) => {
      const [fallbackStart, fallbackEnd] = d.periodKey.split('|');
      const startTime = options.get(d.periodKey)?.startTime ?? fallbackStart;
      const endTime = options.get(d.periodKey)?.endTime ?? fallbackEnd;
      return {
        id: d.id,
        dayOfWeek: d.dayOfWeek,
        startTime,
        endTime,
        room: d.room.trim() || null,
        isLocked: d.isLocked,
        remove: d.remove,
      };
    });

    this.lessonsSaving.set(true);
    this.lessonsError.set(null);
    this.api
      .put<{ updated: number; removed: number }>(`/timetable/teachers/${modal.teacherId}/lessons`, {
        lessons,
        ignoreConflicts: this.lessonsAllowDoubleBooking(),
      })
      .subscribe({
        next: (res) => {
          this.lessonsSaving.set(false);
          const parts: string[] = [];
          if (res.updated) parts.push(`${res.updated} updated`);
          if (res.removed) parts.push(`${res.removed} removed`);
          this.closeTeacherLessons(true);
          this.showToast('success', `Lessons saved for ${modal.teacherName}${parts.length ? ' (' + parts.join(', ') + ')' : ''}.`);
          this.loadSnapshot();
        },
        error: (e) => {
          this.lessonsSaving.set(false);
          this.lessonsError.set(e.error?.message || 'Could not save lessons. Nothing was changed.');
        },
      });
  }

  ngOnInit() {
    this.periods.set(this.periodsSvc.load());
    this.loadTimetableContext();
    this.loadSnapshot();
  }

  private loadTimetableContext() {
    this.api
      .get<{
        termVersionLabel?: string;
        termName?: string | null;
        yearName?: string | null;
        timetableVersion?: string;
      }>('/timetable/context')
      .subscribe({
        next: (ctx) => {
          this.termName.set(ctx.termName ?? null);
          this.yearName.set(ctx.yearName ?? null);
          if (ctx.timetableVersion) {
            this.timetableVersion.set(normalizeTimetableVersion(ctx.timetableVersion));
            this.serverVersion = normalizeTimetableVersion(ctx.timetableVersion);
          }
        },
        error: () => {
          this.termName.set(null);
          this.yearName.set(null);
          this.timetableVersion.set('1');
        },
      });
  }

  onTimetableVersionInput(value: string) {
    this.timetableVersion.set(String(value ?? '').slice(0, 32));
  }

  saveTimetableVersion() {
    const version = normalizeTimetableVersion(this.timetableVersion());
    if (version !== this.timetableVersion()) {
      this.timetableVersion.set(version);
    }
    this.versionSaving.set(true);
    this.api.patch<{ timetableVersion?: string }>('/timetable/version', { version }).subscribe({
      next: (res) => {
        this.versionSaving.set(false);
        if (res.timetableVersion) {
          const saved = normalizeTimetableVersion(res.timetableVersion);
          if (saved !== this.serverVersion) this.versionEdited = true;
          this.serverVersion = saved;
          this.timetableVersion.set(saved);
        }
      },
      error: () => {
        this.versionSaving.set(false);
      },
    });
  }

  ngOnDestroy() {
    document.body.style.overflow = '';
    this.closeSlotMoveHint();
    this.closePdfPreview();
  }

  loadSnapshot(keepTab = false) {
    this.loading.set(true);
    const openEditorMode = this.editorWindow();
    this.api.get<GenerateTimetableResult>('/timetable/generate/snapshot').subscribe({
      next: (data) => {
        this.applyResult(data);
        this.loading.set(false);
        if (this.hasResult()) {
          if (!openEditorMode && !keepTab) {
            this.resultTab.set('teachers');
          }
        } else {
          this.closeEditor();
        }
      },
      error: () => {
        this.result.set(null);
        this.loading.set(false);
      },
    });
  }

  generateTimetable() {
    const periods = this.lessonPeriods();
    if (!periods.length) {
      this.showToast('error', 'Configure lesson periods before generating.');
      return;
    }
    this.generating.set(true);
    this.api
      .post<GenerateTimetableResult>('/timetable/generate', {
        periods: periods.map((p) => ({
          name: p.name,
          startTime: p.startTime,
          endTime: p.endTime,
        })),
        replaceExisting: this.replaceExisting,
        // Only sent when the admin edited it by hand; otherwise the server bumps the version itself.
        ...(this.versionEdited ? { timetableVersion: normalizeTimetableVersion(this.timetableVersion()) } : {}),
      })
      .subscribe({
        next: (data) => {
          if (data.timetableVersion) {
            const v = normalizeTimetableVersion(data.timetableVersion);
            this.timetableVersion.set(v);
            this.serverVersion = v;
          }
          this.versionEdited = false;
          this.applyResult(data);
          this.generating.set(false);
          if (data.summary?.totalSlots) {
            this.resultTab.set('teachers');
          }
          if (data.success) {
            this.showToast('success', `Timetable generated — ${data.summary.totalSlots} slots placed.`);
          } else if (data.summary.totalSlots > 0) {
            this.showToast(
              'error',
              `Timetable partially generated (${data.failures.length} assignment issue(s)). See warnings below.`,
            );
          } else {
            this.showToast('error', data.failures[0]?.reason || 'Could not generate timetable.');
          }
        },
        error: (e) => {
          this.generating.set(false);
          this.showToast('error', e.error?.message || 'Failed to generate timetable.');
        },
      });
  }

  private applyResult(data: GenerateTimetableResult) {
    this.result.set(data);
    if (data.teachers.length) {
      if (!data.teachers.some((t) => t.teacherId === this.selectedTeacherId)) {
        this.selectedTeacherId = data.teachers[0].teacherId;
      }
    } else {
      this.selectedTeacherId = '';
    }
    if (data.classes.length) {
      if (!data.classes.some((c) => c.classId === this.selectedClassId)) {
        this.selectedClassId = data.classes[0].classId;
      }
    } else {
      this.selectedClassId = '';
    }
  }

  setTab(tab: ResultTab) {
    this.resultTab.set(tab);
    this.closeSlotContextMenu();
    this.closeSlotMoveHint();
  }

  openEditor(mode: EditorMode) {
    if (!this.hasResult()) {
      this.showToast('error', 'Generate a timetable before opening the editor.');
      return;
    }
    this.editorWindow.set(mode);
    this.editorPdfMode.set(mode);
    this.resultTab.set(mode);
    document.body.style.overflow = 'hidden';
  }

  closeEditor() {
    this.editorWindow.set(null);
    document.body.style.overflow = '';
    this.closeSlotContextMenu();
    this.closeSlotMoveHint();
  }

  dayLabel(day: number): string {
    return DAYS.find((d) => d.value === day)?.label || `Day ${day}`;
  }

  dayShort(day: number): string {
    return DAYS.find((d) => d.value === day)?.short || `${day}`;
  }

  classDisplayName(name: string): string {
    return classHeaderLabel({ name });
  }

  lessonLengthLabel(length: string): string {
    if (length === 'double') return 'Double';
    if (length === 'triple') return 'Triple';
    return 'Single';
  }

  slotAt(slots: TimetableSlotView[], day: number, period: TimetablePeriod): TimetableSlotView | undefined {
    return slots.find(
      (s) => s.dayOfWeek === day && s.startTime === period.startTime && s.endTime === period.endTime,
    );
  }

  /** All lessons placed in a single cell (supports a teacher teaching 2+ classes at once). */
  slotsAt(slots: TimetableSlotView[], day: number, period: TimetablePeriod): TimetableSlotView[] {
    return slots.filter(
      (s) => s.dayOfWeek === day && s.startTime === period.startTime && s.endTime === period.endTime,
    );
  }

  cellKey(day: number, period: TimetablePeriod): string {
    return `${day}|${period.startTime}|${period.endTime}`;
  }

  teacherRowStyle(teacherId: string): Record<string, string> {
    const style = teacherColorFor(teacherId, this.teacherColorMap());
    return this.colorStyleToCss(style);
  }

  cardStyle(teacherId: string): Record<string, string> {
    const style = teacherColorFor(teacherId, this.teacherColorMap());
    return this.colorStyleToCss(style);
  }

  private colorStyleToCss(style: TeacherColorStyle): Record<string, string> {
    const css: Record<string, string> = {
      background: style.background,
      color: style.color,
    };
    if (style.border) css['border-color'] = style.border;
    return css;
  }

  cardHasBorder(teacherId: string): boolean {
    return !!teacherColorFor(teacherId, this.teacherColorMap()).border;
  }

  findSlotById(slotId: string): TimetableSlotView | undefined {
    for (const teacher of this.teachers()) {
      const hit = teacher.slots.find((s) => s.id === slotId);
      if (hit) return hit;
    }
    for (const cls of this.classes()) {
      const hit = cls.slots.find((s) => s.id === slotId);
      if (hit) return hit;
    }
    return undefined;
  }

  onCardDragStart(slot: TimetableSlotView, event: DragEvent) {
    this.closeSlotMoveHint();
    if (slot.isLocked) {
      event.preventDefault();
      this.showSlotMoveHint(
        'This lesson is locked and cannot be moved.',
        (event.target as HTMLElement)?.closest('.lesson-card') as HTMLElement | null,
        event,
      );
      return;
    }
    event.dataTransfer?.setData('text/plain', slot.id);
    if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move';
    this.draggingSlotId.set(slot.id);
  }

  onCardContextMenu(slot: TimetableSlotView, event: MouseEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.slotContextMenu.set({ x: event.clientX, y: event.clientY, slot });
  }

  closeSlotContextMenu() {
    this.slotContextMenu.set(null);
  }

  hasUnlockableSlots = computed(() =>
    this.teachers().some((t) => t.slots.some((s) => !s.isLocked)),
  );

  hasLockableSlots = computed(() =>
    this.teachers().some((t) => t.slots.some((s) => !!s.isLocked)),
  );

  lockAllPlacedCards() {
    this.setBulkSlotLocked(true);
  }

  unlockAllPlacedCards() {
    this.setBulkSlotLocked(false);
  }

  setSlotLocked(slot: TimetableSlotView, locked: boolean) {
    if (this.slotLockUpdating()) return;
    this.closeSlotContextMenu();
    this.slotLockUpdating.set(true);
    this.api.patch(`/timetable/slots/${slot.id}/lock`, { locked }).subscribe({
      next: () => {
        this.slotLockUpdating.set(false);
        this.loadSnapshot();
      },
      error: (e) => {
        this.slotLockUpdating.set(false);
        this.showToast('error', e.error?.message || 'Could not update lesson lock.');
      },
    });
  }

  private setBulkSlotLocked(locked: boolean) {
    if (this.slotLockUpdating()) return;
    this.closeSlotContextMenu();
    this.slotLockUpdating.set(true);
    this.api.patch<{ updated: number }>('/timetable/slots/lock-bulk', { locked }).subscribe({
      next: (res) => {
        this.slotLockUpdating.set(false);
        const count = res?.updated ?? 0;
        if (count > 0) {
          this.showToast(
            'success',
            locked ? `Locked ${count} lesson${count === 1 ? '' : 's'}.` : `Unlocked ${count} lesson${count === 1 ? '' : 's'}.`,
          );
        }
        this.loadSnapshot();
      },
      error: (e) => {
        this.slotLockUpdating.set(false);
        this.showToast('error', e.error?.message || 'Could not update lesson locks.');
      },
    });
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent) {
    const target = event.target as HTMLElement;
    if (target.closest('.slot-context-menu')) return;
    this.closeSlotContextMenu();
    this.closeTeacherContextMenu();
  }

  @HostListener('document:keydown.escape')
  onEscapeKey() {
    // The assignments modal handles its own Escape key.
    if (this.assignmentsModal()) return;
    if (this.slotMoveHint()) {
      this.closeSlotMoveHint();
      return;
    }
    if (this.lessonsModal()) {
      this.closeTeacherLessons();
      return;
    }
    if (this.teacherContextMenu()) {
      this.closeTeacherContextMenu();
      return;
    }
    if (this.slotContextMenu()) {
      this.closeSlotContextMenu();
      return;
    }
    if (this.editorWindow()) {
      this.closeEditor();
      return;
    }
    if (this.pdfPreviewOpen()) {
      this.closePdfPreview();
      return;
    }
  }

  onCardDragEnd() {
    this.draggingSlotId.set(null);
    this.dragOverKey.set(null);
  }

  onCellDragOver(day: number, period: TimetablePeriod, event: DragEvent) {
    if (isBreakPeriod(period)) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    this.dragOverKey.set(this.cellKey(day, period));
  }

  onCellDragLeave(day: number, period: TimetablePeriod) {
    if (this.dragOverKey() === this.cellKey(day, period)) {
      this.dragOverKey.set(null);
    }
  }

  onCellDrop(
    ownerId: string,
    day: number,
    period: TimetablePeriod,
    mode: 'teacher' | 'class',
    slots: TimetableSlotView[],
    event: DragEvent,
  ) {
    event.preventDefault();
    this.dragOverKey.set(null);
    const dropCell = event.currentTarget as HTMLElement | null;
    if (isBreakPeriod(period) || this.slotMoving()) return;

    const slotId = event.dataTransfer?.getData('text/plain') || this.draggingSlotId();
    if (!slotId) return;

    const slot = this.findSlotById(slotId);
    if (!slot) return;

    if (slot.isLocked) {
      this.showSlotMoveHint(
        'This lesson is locked and cannot be moved.',
        this.moveHintAnchor(dropCell),
        event,
      );
      return;
    }

    if (mode === 'teacher' && slot.teacherId !== ownerId) {
      this.showSlotMoveHint(
        'Drag lessons along the same teacher row only.',
        this.moveHintAnchor(dropCell),
        event,
      );
      return;
    }
    if (mode === 'class' && slot.classId !== ownerId) {
      this.showSlotMoveHint(
        'Drag lessons along the same class row only.',
        this.moveHintAnchor(dropCell),
        event,
      );
      return;
    }

    if (
      slot.dayOfWeek === day &&
      slot.startTime === period.startTime &&
      slot.endTime === period.endTime
    ) {
      return;
    }

    const occupied = this.slotAt(slots, day, period);
    if (occupied && occupied.id !== slotId) {
      // Manual move onto an already-occupied slot in the teacher grid: let the user
      // decide — ignore the conflict to place the lesson here (teacher takes both), or cancel.
      if (mode === 'teacher') {
        this.showSlotMoveHint(
          `${slot.className} would share this period with ${occupied.className} for this teacher.`,
          dropCell,
          event,
          {
            label: 'Ignore conflicts',
            run: () => this.performSlotMove(slotId, day, period, dropCell, event, true),
          },
        );
      } else {
        this.showSlotMoveHint('That period already has a lesson.', dropCell, event);
      }
      return;
    }

    this.performSlotMove(slotId, day, period, dropCell, event, false);
  }

  private performSlotMove(
    slotId: string,
    day: number,
    period: TimetablePeriod,
    dropCell: HTMLElement | null,
    event: DragEvent | MouseEvent | undefined,
    ignoreConflicts: boolean,
  ) {
    this.closeSlotMoveHint();
    this.slotMoving.set(true);
    this.api
      .patch(`/timetable/slots/${slotId}/move`, {
        dayOfWeek: day,
        startTime: period.startTime,
        endTime: period.endTime,
        ignoreConflicts,
      })
      .subscribe({
        next: () => {
          this.slotMoving.set(false);
          this.draggingSlotId.set(null);
          this.loadSnapshot();
        },
        error: (e) => {
          this.slotMoving.set(false);
          this.showSlotMoveHint(
            e.error?.message || 'Could not move lesson.',
            this.moveHintAnchor(dropCell),
            event,
          );
        },
      });
  }

  slotsForDay(slots: TimetableSlotView[], day: number): TimetableSlotView[] {
    return slots
      .filter((s) => s.dayOfWeek === day)
      .sort((a, b) => a.startTime.localeCompare(b.startTime));
  }

  assignmentStatus(scheduled: number, required: number): 'ok' | 'partial' | 'missing' {
    if (scheduled >= required) return 'ok';
    if (scheduled > 0) return 'partial';
    return 'missing';
  }

  requiredPeriodsFor(row: TeacherSummaryRow): number {
    return row.assignments.reduce((s, a) => s + a.requiredPeriods, 0);
  }

  periodIndexLabel(index: number): string | number {
    const period = this.periods()[index];
    if (isBreakPeriod(period)) return breakPeriodHeaderTitle(period);
    const value = lessonPeriodNumber(this.periods(), index);
    if (value === null) return breakPeriodHeaderTitle(period);
    return value;
  }

  gridRowLabelHeader(mode: 'teachers' | 'classes'): string {
    return mode === 'teachers' ? 'TR' : 'Class';
  }

  gridRowCount(mode: 'teachers' | 'classes'): number {
    return mode === 'teachers' ? this.summaryGridTeachers().length : this.classes().length;
  }

  summaryCell(teacher: { slots: TimetableSlotView[] }, day: number, period: TimetablePeriod): string {
    if (isBreakPeriod(period)) return '';
    const matches = teacher.slots.filter(
      (s) => s.dayOfWeek === day && s.startTime === period.startTime && s.endTime === period.endTime,
    );
    if (!matches.length) return '';
    return [...new Set(matches.map((s) => shortClassCode(s.className)).filter(Boolean))].join('/');
  }

  previewSummaryPdf() {
    this.exportSummaryPdf(true);
  }

  downloadSummaryPdf() {
    this.exportSummaryPdf(false);
  }

  previewTeacherPdf() {
    this.exportTeacherPdf(true);
  }

  /** Right-click a teacher's initials to choose: preview PDF or edit lessons. */
  onTeacherContextMenu(teacherId: string, teacherName: string, event: MouseEvent) {
    event.preventDefault();
    event.stopPropagation();
    if (!teacherId) return;
    this.closeSlotContextMenu();
    this.teacherContextMenu.set({ x: event.clientX, y: event.clientY, teacherId, teacherName });
  }

  closeTeacherContextMenu() {
    this.teacherContextMenu.set(null);
  }

  /** Menu action: preview the selected teacher's timetable PDF. */
  previewTeacherFromMenu() {
    const menu = this.teacherContextMenu();
    if (!menu) return;
    this.selectedTeacherId = menu.teacherId;
    this.closeTeacherContextMenu();
    this.previewTeacherPdf();
  }

  /** Menu action: open the Current assignments modal for the right-clicked teacher. */
  editAssignmentsFromMenu() {
    const menu = this.teacherContextMenu();
    if (!menu) return;
    this.openTeacherAssignments(menu.teacherId, menu.teacherName);
  }

  /** Menu action: open the timetable-slot editor for the right-clicked teacher. */
  editLessonsFromMenu() {
    const menu = this.teacherContextMenu();
    if (!menu) return;
    this.openTeacherLessons(menu.teacherId, menu.teacherName);
  }

  downloadTeacherPdf() {
    this.exportTeacherPdf(false);
  }

  previewClassPdf() {
    this.exportClassPdf(true);
  }

  downloadClassPdf() {
    this.exportClassPdf(false);
  }

  previewEditorPdf() {
    if (!this.editorWindow()) return;
    if (this.editorPdfMode() === 'teachers') {
      this.exportAllTeachersPdf(true);
      return;
    }
    this.exportAllClassesPdf(true);
  }

  private exportAllTeachersPdf(preview: boolean) {
    if (!this.hasResult()) {
      this.showToast('error', 'Generate a timetable before exporting the PDF.');
      return;
    }
    this.editorPdfLoading.set(true);
    const params: Record<string, string> = {
      periods: this.periodsPayload(),
    };
    if (preview) params['preview'] = 'true';
    this.exportGridPdf('/timetable/generate/teachers/all/pdf', params, preview, 'all-teacher-timetables.pdf', () =>
      this.editorPdfLoading.set(false),
    preview ? `All teacher timetables · ${this.termVersionLabel()}` : 'All teacher timetables',
    );
  }

  private exportAllClassesPdf(preview: boolean) {
    if (!this.hasResult()) {
      this.showToast('error', 'Generate a timetable before exporting the PDF.');
      return;
    }
    this.editorPdfLoading.set(true);
    const params: Record<string, string> = {
      periods: this.periodsPayload(),
    };
    if (preview) params['preview'] = 'true';
    this.exportGridPdf('/timetable/generate/classes/all/pdf', params, preview, 'all-class-timetables.pdf', () =>
      this.editorPdfLoading.set(false),
    preview ? `All class timetables · ${this.termVersionLabel()}` : 'All class timetables',
    );
  }

  private periodsPayload(): string {
    return JSON.stringify(
      this.periods().map((p) => ({
        name: p.name,
        startTime: p.startTime,
        endTime: p.endTime,
        slotType: p.slotType,
      })),
    );
  }

  private exportTeacherPdf(preview: boolean) {
    if (!this.selectedTeacherId) {
      this.showToast('error', 'Select a teacher first.');
      return;
    }
    this.teacherPdfLoading.set(true);
    const params: Record<string, string> = {
      teacherId: this.selectedTeacherId,
      periods: this.periodsPayload(),
    };
    if (preview) params['preview'] = 'true';
    this.exportGridPdf('/timetable/generate/teacher/pdf', params, preview, `timetable-teacher.pdf`, () =>
      this.teacherPdfLoading.set(false),
    preview ? this.teacherPdfPreviewTitle() : 'Teacher timetable',
    );
  }

  private exportClassPdf(preview: boolean) {
    if (!this.selectedClassId) {
      this.showToast('error', 'Select a class first.');
      return;
    }
    this.classPdfLoading.set(true);
    const params: Record<string, string> = {
      classId: this.selectedClassId,
      periods: this.periodsPayload(),
    };
    if (preview) params['preview'] = 'true';
    this.exportGridPdf('/timetable/generate/class/pdf', params, preview, `timetable-class.pdf`, () =>
      this.classPdfLoading.set(false),
    preview ? this.classPdfPreviewTitle() : 'Class timetable',
    );
  }

  private exportGridPdf(
    path: string,
    params: Record<string, string>,
    preview: boolean,
    downloadName: string,
    onDone: () => void,
    previewTitle = 'Timetable PDF',
  ) {
    this.api.getBlob(path, params).subscribe({
      next: (blob) => {
        onDone();
        if (blob.type && !blob.type.includes('pdf')) {
          this.showToast('error', 'Server did not return a PDF file.');
          return;
        }
        if (preview) {
          this.openPdfPreview(blob, downloadName, previewTitle);
          return;
        }
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = downloadName;
        a.click();
        URL.revokeObjectURL(url);
      },
      error: async (e) => {
        onDone();
        this.showToast('error', await blobErrorMessage(e, 'Failed to generate PDF.'));
      },
    });
  }

  downloadPdfPreview() {
    if (!this.pdfObjectUrl) return;
    const a = document.createElement('a');
    a.href = this.pdfObjectUrl;
    a.download = this.pdfDownloadName();
    a.click();
  }

  closePdfPreview() {
    this.pdfPreviewOpen.set(false);
    this.revokePdfObjectUrl();
    document.body.style.overflow = '';
  }

  private openPdfPreview(blob: Blob, downloadName: string, title: string) {
    this.revokePdfObjectUrl();
    this.pdfObjectUrl = URL.createObjectURL(blob);
    this.pdfDownloadName.set(downloadName);
    this.pdfPreviewTitle.set(title);
    this.pdfPreviewUrl.set(this.sanitizer.bypassSecurityTrustResourceUrl(this.pdfObjectUrl));
    this.pdfPreviewOpen.set(true);
    document.body.style.overflow = 'hidden';
  }

  private revokePdfObjectUrl() {
    if (this.pdfObjectUrl) {
      URL.revokeObjectURL(this.pdfObjectUrl);
      this.pdfObjectUrl = null;
    }
    this.pdfPreviewUrl.set(null);
  }

  private teacherPdfPreviewTitle(): string {
    const teacher = this.teachers().find((t) => t.teacherId === this.selectedTeacherId);
    return teacher ? `Teacher: ${teacher.teacherName}` : 'Teacher timetable';
  }

  private classPdfPreviewTitle(): string {
    const cls = this.classes().find((c) => c.classId === this.selectedClassId);
    return cls ? `Class: ${this.classDisplayName(cls.className)}` : 'Class timetable';
  }

  private exportSummaryPdf(preview: boolean) {
    if (!this.hasResult()) {
      this.showToast('error', 'Generate a timetable before exporting the summary PDF.');
      return;
    }
    this.summaryPdfLoading.set(true);
    const params: Record<string, string> = {
      periods: this.periodsPayload(),
    };
    if (preview) params['preview'] = 'true';

    this.exportGridPdf('/timetable/generate/summary/pdf', params, preview, 'teacher-summary-timetable.pdf', () =>
      this.summaryPdfLoading.set(false),
    preview ? `Summary timetable · ${this.termVersionLabel()}` : 'Summary timetable',
    );
  }

  private moveHintAnchor(dropCell: HTMLElement | null): HTMLElement | null {
    return (document.querySelector('.lesson-card.dragging') as HTMLElement | null) ?? dropCell;
  }

  private showSlotMoveHint(
    msg: string,
    anchor?: HTMLElement | null,
    event?: MouseEvent | DragEvent,
    action?: { label: string; run: () => void },
  ) {
    if (this.slotMoveHintTimer) {
      clearTimeout(this.slotMoveHintTimer);
      this.slotMoveHintTimer = null;
    }

    let x = event?.clientX ?? window.innerWidth / 2;
    let y = event?.clientY ?? window.innerHeight / 2;
    let above = false;

    if (anchor) {
      const rect = anchor.getBoundingClientRect();
      x = rect.left + rect.width / 2;
      y = rect.bottom + 6;
      const maxY = window.innerHeight - 12;
      if (y > maxY) {
        y = rect.top - 6;
        above = true;
      }
    }

    this.slotMoveHint.set({ x, y, msg, above, action });
    // Actionable (conflict) hints require an explicit choice — Ignore, Cancel, Esc, or a
    // new drag dismisses them — so they are not auto-dismissed on a timer.
    if (!action) {
      this.slotMoveHintTimer = setTimeout(() => this.closeSlotMoveHint(), 5000);
    }
  }

  runSlotMoveHintAction() {
    const action = this.slotMoveHint()?.action;
    if (action) action.run();
  }

  closeSlotMoveHint() {
    if (this.slotMoveHintTimer) {
      clearTimeout(this.slotMoveHintTimer);
      this.slotMoveHintTimer = null;
    }
    this.slotMoveHint.set(null);
  }

  private showToast(type: 'success' | 'error', msg: string) {
    this.toast.set({ type, msg });
    setTimeout(() => this.toast.set(null), 5000);
  }
}
