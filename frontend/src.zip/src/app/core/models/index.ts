export type UserRole = 'director' | 'principal' | 'admin' | 'accountant' | 'teacher' | 'parent' | 'student';

export interface User {
  id: string;
  email: string;
  username?: string | null;
  firstName: string;
  lastName: string;
  gender?: string | null;
  /** 'single' | 'married' – used to choose Miss / Mrs / Ms in greetings. */
  maritalStatus?: string | null;
  /** Married women who still use their maiden name are addressed as Ms. */
  usesMaidenName?: boolean | null;
  /** Optional explicit title (Dr, Prof, Rev…) that overrides the automatic rule. */
  salutation?: string | null;
  role: UserRole;
  schoolRoleId?: string | null;
  schoolRoleName?: string | null;
  permissions?: string[];
  staffId?: string;
  parentId?: string;
  studentId?: string;
  /**
   * Set when a staff member (e.g. a teacher who also has children at the school) signs in
   * through the Parent portal: the account's own role, while `role` is the portal in use.
   */
  accountRole?: UserRole;
}

export interface AuthResponse {
  token: string;
  user: User;
  /** Present on tokens issued by POST /auth/demo-login. */
  demo?: boolean;
  sessionTimeoutMinutes?: number;
  /** Set when the security policy requires the user to pick a new password. */
  passwordChangeRequired?: boolean;
  passwordChangeReason?: 'first-login' | 'expired' | null;
}

export interface DemoAccount {
  role: UserRole;
  username: string;
  password: string;
  label: string;
  description: string;
}

export interface Student {
  id: string;
  /** Linked portal user account (users.id), when the student has one. */
  userId?: string | null;
  /** Display label: Student ID (stored as admissionNumber) */
  admissionNumber: string;
  firstName: string;
  lastName: string;
  dateOfBirth?: string;
  gender?: string;
  studentType?: 'day_scholar' | 'boarder';
  classId?: string;
  formId?: string;
  enrollmentDate?: string;
  schoolClass?: { name: string; form?: { name: string } };
  form?: { id: string; name: string; level: number };
  guardians?: Guardian[];
  address?: string;
  previousSchool?: string;
  photoUrl?: string;
}

export interface Guardian {
  id?: string;
  fullName: string;
  relationship: string;
  phone: string;
  guardianPhone?: string;
  guardianWhatsappConsent?: boolean;
  email?: string;
  isPrimary?: boolean;
}

export interface DashboardOverview {
  totalStudents: number;
  boarders: number;
  dayScholars: number;
  totalStaff: number;
  maleStaff: number;
  femaleStaff: number;
  attendanceToday: { status: string; count: string }[];
  monthlyCollections: number;
  totalDebtors: number;
  lowStockItems: number;
}
