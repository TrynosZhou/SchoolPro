import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import fs from 'fs';
import path from 'path';
import { env } from './config/env';
import { getStartupState } from './server';

import authRoutes from './routes/auth.routes';
import studentsRoutes from './routes/students.routes';
import attendanceRoutes from './routes/attendance.routes';
import examsRoutes from './routes/exams.routes';
import billingRoutes from './routes/billing.routes';
import financeRoutes from './routes/finance.routes';
import academicsRoutes from './routes/academics.routes';
import timetableRoutes from './routes/timetable.routes';
import adminRoutes from './routes/admin.routes';
import dashboardRoutes from './routes/dashboard.routes';
import payrollRoutes from './routes/payroll.routes';
import generalLedgerRoutes from './routes/general-ledger.routes';
import chartOfAccountsRoutes from './routes/chart-of-accounts.routes';
import teacherAssignmentRoutes from './routes/teacher-assignment.routes';
import admissionsRoutes from './routes/admissions.routes';
import publicRoutes from './routes/public.routes';
import communicationRoutes from './routes/communication.routes';
import analyticsRoutes from './routes/analytics.routes';
import reportsRoutes from './routes/reports.routes';
import accessControlRoutes from './routes/access-control.routes';
import webhooksRoutes from './routes/webhooks.routes';
import lmsRoutes from './routes/lms.routes';
import { tenantContextMiddleware } from './middleware/tenant-context.middleware';
import { demoGlobalWriteGuard, demoWriteRateLimiter } from './middleware/demo-guard.middleware';

const app = express();

app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
  }),
);

function resolveFrontendBrowserDir(): string | null {
  const candidates = [
    path.resolve(process.cwd(), '..', 'frontend', 'dist', 'browser'),
    path.resolve(process.cwd(), 'frontend', 'dist', 'browser'),
    path.resolve(__dirname, '..', '..', 'frontend', 'dist', 'browser'),
    path.resolve(__dirname, '..', '..', '..', 'frontend', 'dist', 'browser'),
  ];
  for (const candidate of candidates) {
    try {
      const indexHtml = path.join(candidate, 'index.html');
      if (fs.existsSync(indexHtml)) return candidate;
    } catch {
      /* ignore */
    }
  }
  return null;
}

const frontendDir = resolveFrontendBrowserDir();

app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

if (frontendDir) {
  app.use(
    express.static(frontendDir, {
      maxAge: env.nodeEnv === 'production' ? '1y' : 0,
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('index.html')) {
          res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        }
      },
    }),
  );
}

function normalizeOrigin(s: string): string {
  let out = String(s);
  out = out.replace(/[\x00-\x1F\x7F]/g, '');
  out = out.replace(/^\s+|\s+$/g, '');
  out = out.replace(/\/+$/, '');
  return out;
}

const allowedOrigins = env.frontendUrl
  .split(',')
  .map((v) => normalizeOrigin(v))
  .filter(Boolean);

function startsWithAny(p: string, prefixes: string[]): boolean {
  for (const prefix of prefixes) if (p.startsWith(prefix)) return true;
  return false;
}

const API_PREFIXES = ['/api/', '/webhooks/', '/uploads/'];
const HEALTH_PATH = '/api/health';

function isApiOrProtectedPath(pathname: string): boolean {
  if (pathname === HEALTH_PATH) return true;
  return startsWithAny(pathname, API_PREFIXES);
}

app.use((req, res, next) => {
  const method = (req.method || 'GET').toUpperCase();
  if (!isApiOrProtectedPath(req.path)) {
    if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') {
      return next();
    }
  }

  const corsHandler = cors({
    origin: (origin, callback) => {
      if (!origin) return callback(null, true);
      const normalizedOrigin = normalizeOrigin(origin);
      if (allowedOrigins.includes(normalizedOrigin)) return callback(null, true);
      if (allowedOrigins.includes('*')) return callback(null, true);
      if (env.nodeEnv === 'development' && /^http:\/\/localhost:\d+$/.test(normalizedOrigin)) {
        return callback(null, true);
      }
      return callback(new Error(`CORS blocked for origin: \`${origin}\``));
    },
    credentials: true,
  });
  corsHandler(req, res, next);
});

app.use((req, res, next) => {
  if (!isApiOrProtectedPath(req.path)) return next();
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') return next();
  express.json()(req, res, next);
});

app.use(express.json());

app.use((req, res, next) => {
  if (!isApiOrProtectedPath(req.path)) return next();
  const state = getStartupState();
  if (state.ok) return next();
  const trimmedPath = req.path.endsWith('/') && req.path.length > 1
    ? req.path.slice(0, -1)
    : req.path;
  const isPublicSafe =
    trimmedPath === '/api/health' ||
    trimmedPath.startsWith('/api/public') ||
    trimmedPath === '/api/auth/password-policy' ||
    trimmedPath.startsWith('/webhooks');
  if (isPublicSafe) return next();
  res.setHeader('Retry-After', '30');
  return res.status(503).json({
    message: 'Database is warming up or unreachable — please retry in a moment.',
  });
});

app.use((req, res, next) => {
  if (!isApiOrProtectedPath(req.path)) return next();
  tenantContextMiddleware(req, res, next);
}, demoWriteRateLimiter, demoGlobalWriteGuard);

app.get('/api/health', (_req, res) => {
  const state = getStartupState();
  res.json({
    status: state.ok ? 'ok' : 'degraded',
    degraded: !state.ok,
    sslMode: state.sslMode,
    error: state.error ? { name: state.error.name, message: state.error.message } : undefined,
    service: 'School Pro API',
  });
});

app.use('/api/auth', authRoutes);
app.use('/api/students', studentsRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/exams', examsRoutes);
app.use('/api/billing', billingRoutes);
app.use('/api/finance', financeRoutes);
app.use('/api/academics', academicsRoutes);
app.use('/api/timetable', timetableRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/payroll', payrollRoutes);
app.use('/api/general-ledger', generalLedgerRoutes);
app.use('/api/chart-of-accounts', chartOfAccountsRoutes);
app.use('/api/admin/assignments', teacherAssignmentRoutes);
app.use('/api/admissions', admissionsRoutes);
app.use('/api/public', publicRoutes);
app.use('/api/communication', communicationRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/reports', reportsRoutes);
app.use('/api/access-control', accessControlRoutes);
app.use('/api/lms', lmsRoutes);
app.use('/webhooks', webhooksRoutes);

if (frontendDir) {
  app.use((req, res, next) => {
    if (req.method !== 'GET') return next();
    const pathname = req.path;
    if (
      pathname.startsWith('/api/') ||
      pathname.startsWith('/uploads/') ||
      pathname.startsWith('/webhooks/') ||
      pathname === '/api/health'
    ) {
      return next();
    }
    const indexHtml = path.join(frontendDir, 'index.html');
    if (fs.existsSync(indexHtml)) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      return res.sendFile(indexHtml);
    }
    next();
  });
} else {
  console.warn(
    '[app] Frontend build (frontend/dist/browser/index.html) not found — ' +
      'SPA routes like /login will 404. Run `npm run build:frontend` from the monorepo root ' +
      'or serve the Angular dev server separately via `cd frontend && npm start`.',
  );
}

app.use((err: Error, req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const payload: Record<string, unknown> = {
    name: err?.name,
    message: err?.message,
    code: (err as { code?: string })?.code,
    url: req.originalUrl,
    method: req.method,
    user: (req as { user?: { userId?: string; role?: string; email?: string } })?.user
      ? {
          userId: (req as { user?: { userId?: string } }).user?.userId,
          role: (req as { user?: { role?: string } }).user?.role,
          email: (req as { user?: { email?: string } }).user?.email,
        }
      : undefined,
    stack: err?.stack?.split('\n').slice(0, 6).join('\n'),
  };
  console.error('[http:500] request failed:', JSON.stringify(payload, null, 2));
  res.status(500).json({ message: 'Internal server error', error: env.nodeEnv === 'development' ? err.message : undefined });
});

export default app;

